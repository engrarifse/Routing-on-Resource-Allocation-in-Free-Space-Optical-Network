function [ A_Reduced,Num_Link_new ] = Gamma_Gamma_reduction(A,lambd,P,T,C_t2,dist,gamma_th )
%Input: A = node-link incidence matrox (N by L)
%           lambda = wave length (in meter)
%           dist = distance (in meter)
%          P:  air pressure
%           T:air temopreture
%           C_t2: tempreture structure constante


count=1;
for link=1:size(A,2)
    i=find(A(:,link)==1);
    j=find(A(:,link)==-1);
    g =gamma_gamma(P,T,C_t2,lambd,dist(i,j)) ;
    if g>=gamma_th
       A_Reduced(:,count)=A(:,link);
       count=count+1;
    end
    
end;
Num_Link_new=count-1;
end