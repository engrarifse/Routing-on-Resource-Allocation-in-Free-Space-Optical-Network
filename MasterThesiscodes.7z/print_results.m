function  print_results( links,W_L,P_L,T_OPT,P_tot,W_tot )

% links = sort(links,1);
% disp( sprintf( 'Hello, %d worlds!', 20 ) )

  
         disp(sprintf('After Optimization'))
        disp(sprintf('#\t\t\tLink\t\t\tBandwidth\t\t\tPower'))
	    for row = 1:size(links,1)
             disp( sprintf( '%d\t\t\t(%d,%d)->\t\t%d\t\t%d',row, links(row,1), links(row,2), W_L(1,row), P_L(1,row) ) )
            
        end


end

