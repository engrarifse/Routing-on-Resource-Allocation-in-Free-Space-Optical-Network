function p =gamma_gamma(P,T,C_t2,lambd,dist)
%%The Gamma-gamma  
%based on Optical Wireless Communications System and Channel Modelling

%%computing alpha and beta
C_n2=(79*10^(-6)*P/(T^2))^2*C_t2;
k_m=(2*pi)/lambd ;
Rytov_var=0.5*C_n2*((k_m)^(7/6))*(dist^(11/6));
A=(0.49*Rytov_var)/(1+1.11*Rytov_var^(6/5))^(7/6);
B=(0.51*Rytov_var)/(1+0.69*Rytov_var^(6/5))^(5/6); 
alpha=(exp(A)- 1)^-1; 
beta=(exp(B)- 1)^-1; 

%computing gamma-gamme
a=alpha;
b=beta; 
k=(a+b)/2; 
k1=a*b;
K =2*(k1^k)/(gamma(a)*gamma(b));
Z=2*sqrt(k1);
p=K.*k1.*besselk((a-b),Z);


end

