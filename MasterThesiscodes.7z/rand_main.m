%Inputs
close all;
clear all;
n=30;  %Number of Nodes
l=60;  %Initial Number of links
Number_links = l;
Number_Links = l;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
condition=1;          %0= noreduction, 1=just log-normal,2=just gamma-gamma,3= both log-normal and gamma-gamma
lambd = 1550e-9;      %in nano Meter wave length
g_th=0.9;             %reliability OWC link
I_0 = 10;             %Average Intensity current-- from the paper Design and
P_Max=100;            %Maximum power of each nodes (P_tot)
W_Max=50;             %Maximum bandwidths           (W_tot)
delta_max=1;          %maximun of power spectral densities
I_th = 8;             %Intensity threshold
%% parameters for gamma gamma
gamma_th=5;           %thershold for gamma_gamma
P=10;                 %air pressure
T=23;                 %tempreture
C_t2=20;              %tempreture structure constante
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% parameters of DUAL_DECOMPOSITION algorithm
Num_iteration=600;
Beta=0.1;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Gneration initial network randomly'
mark_destination_nodes=zeros(1,n);
mark_destination_nodes(20)=1;

mark_destination_nodes(30)=1;
% mark_destination_nodes(5)=1;
mark_destination_nodes(14)=1;
% mark_destination_nodes(8)=1;
mark_soruce_node=zeros(1,n);
mark_soruce_node(2)=1;
% mark_destination_nodes(5)=1;
mark_soruce_node(10)=1;


mark_soruce_node(23)=1;

[A,dist,x,y,adj_matrix]=make_data(n,l,mark_destination_nodes,mark_soruce_node);




 p=randi(10,1,Number_Links);    %Initial_point for DUAL_DECOMPOSITION algorithm
    %generating Power and bandwithds of Nodes randomly
    for i=1:n
        P_tot(i)=(P_Max/2)+(P_Max/2)*rand();        %maximum power node i between (P_Max/2, P_Max)
        W_tot(i)=(W_Max/2)+(W_Max/2)*rand();        %maximum bandwidths node i between (W_Max/2, W_Max)
    end;
    for i=1:Number_Links
        delta(i)=(delta_max/2)+(delta_max/2)*2;       % power spectral densities of link i
    end;
    

count =1;
for colum = 1:size(A,2)
    for row = 1:size(A,1)
      flag = 0;
          if A(row,colum) == 1
              links(count,1) = row;  
            flag= 1;
           
          end
          if A(row,colum) == -1
             
              links(count,2) = row; 
                  flag= 1;
              
          end         
    end
        count =  count+1;
end

% inploimenting LOG_Normal to the network, the result network maybe become
% smaller than the original generated network

% inploimenting LOG_Normal to the network, the result network maybe become
% smaller than the original generated network

g=[ P_tot W_tot]; % resource limits 
A_Reduced=A;
Number_Links=l;
% create links array for printing output
links = create_link_map( A_Reduced );
[flag,Destination_Nodes ] = CheckMatrix( A_Reduced);
[V,X_OPT,S_OPT,T_OPT,P_L,W_L,P_value,v_n,v_c,gradient,m_p]=DUAL_DECOMPOSITION (A_Reduced ,g,delta,Destination_Nodes,Num_iteration,Beta,p(1:size(A_Reduced,2)));

find_shortest_path(n,l,A_Reduced,links,W_L,P_L, mark_soruce_node,mark_destination_nodes );
my_length=size(m_p',2);
figure(1)
plot(1:my_length, mean(m_p(1:my_length,:)'),'r-',1:my_length,mean(gradient(1:my_length,:)'),'g-.');
set(gca,'FontSize',12); 
legend('�','gradient','Location','northeast');
ylabel('�, gradient');
xlabel('iteration');



figure(2)
plot(1:size(V,2),V,'r-',1:size(v_n,2),v_n,'g-.',1:size(v_c,2),v_c*100,'b-');
set(gca,'FontSize',12); 
legend('f(x,s,r,t)','routing problem','communication problem','Location','northeast');
xlabel('iteration');
ylabel('problems');
disp('Figure 2: Simulation result without any atmospheric turbulence after optimization')
print_results( links,W_L,P_L,T_OPT );


clear V X_OPT S_OPT T_OPT P_L W_L P_value v_n v_c gradient A_Reduced ;
[ A_Reduced,Number_Links ] = Log_Normal(A,lambd,I_th,I_0,dist,g_th );

% create links array for printing output
links = create_link_map( A_Reduced );
[flag,Destination_Nodes ] = CheckMatrix( A_Reduced);
[V,X_OPT,S_OPT,T_OPT,P_L,W_L,P_value,v_n,v_c,gradient]=DUAL_DECOMPOSITION (A_Reduced ,g,delta,Destination_Nodes,Num_iteration,Beta,p(1:size(A_Reduced,2)));
 
find_shortest_path(n,l,A_Reduced,links,W_L,P_L, mark_soruce_node,mark_destination_nodes )
my_length=size(gradient',2);
figure(3);
plot(1:my_length, mean(P_value(1:my_length,1:size(A_Reduced,2))'),'r-',1:my_length,mean(gradient(1:my_length,1:size(A_Reduced,2))'),'g-.');
set(gca,'FontSize',12); 
legend('�','gradient','Location','northeast');
ylabel('�, gradient');
xlabel('iteration');


figure(4);
plot(1:size(V,2),V,'r-',1:size(v_n,2),v_n,'g-.',1:size(v_c,2),v_c*100,'b-');
set(gca,'FontSize',12); 
legend('f(x,s,r,t)','routing problem','communication problem','Location','northeast');
xlabel('iteration');
ylabel('problems');
disp('Figure 4: Simulation result under log-normal after optimization')
print_results( links,W_L,P_L,T_OPT );

 
clear V X_OPT S_OPT T_OPT P_L W_L P_value v_n v_c gradient A_Reduced ;
[ A_Reduced,Num_Link_new ] = Gamma_Gamma_reduction(A,lambd,P,T,C_t2,dist,gamma_th );
links = create_link_map( A_Reduced );
[flag,Destination_Nodes ] = CheckMatrix( A_Reduced);
[V,X_OPT,S_OPT,T_OPT,P_L,W_L,P_value,v_n,v_c,gradient]=DUAL_DECOMPOSITION (A_Reduced ,g,delta,Destination_Nodes,Num_iteration,Beta,p(1:size(A_Reduced,2)));

find_shortest_path(n,l,A_Reduced,links,W_L,P_L, mark_soruce_node,mark_destination_nodes )
my_length=size(gradient',2);
figure(5)
plot(1:my_length, mean(P_value(1:my_length,1:size(A_Reduced,2))'),'r-',1:my_length,mean(gradient(1:my_length,1:size(A_Reduced,2))'),'g-.');
set(gca,'FontSize',12); 
legend('�','gradient','Location','northeast');
ylabel('�, gradient');
xlabel('iteration')


figure(6)
plot(1:size(V,2),V,'r-',1:size(v_n,2),v_n,'g-.',1:size(v_c,2),v_c*100,'b-');
set(gca,'FontSize',12); 
legend('f(x,s,r,t)','routing problem','communication problem','Location','northeast');
xlabel('iteration');
ylabel('problems');
disp('Figure 6: Simulation result under gamma-gamma after optimization')
print_results( links,W_L,P_L,T_OPT );


clear V X_OPT S_OPT T_OPT P_L W_L P_value v_n v_c gradient A_Reduced ;
[ A_Reduced,Number_Links ] = Log_Normal(A,lambd,I_th,I_0,dist,g_th );
    [ A_Reduced,Number_Links ] = Gamma_Gamma_reduction(A_Reduced,lambd,P,T,C_t2,dist,gamma_th );
links = create_link_map( A_Reduced );
    [flag,Destination_Nodes ] = CheckMatrix( A_Reduced);
[V,X_OPT,S_OPT,T_OPT,P_L,W_L,P_value,v_n,v_c,gradient]=DUAL_DECOMPOSITION (A_Reduced ,g,delta,Destination_Nodes,Num_iteration,Beta,p(1:size(A_Reduced,2)));

find_shortest_path(n,l,A_Reduced,links,W_L,P_L, mark_soruce_node,mark_destination_nodes )

my_length=size(gradient',2);
figure(7)
plot(1:my_length, mean(P_value(1:my_length,1:size(A_Reduced,2))'),'r-',1:my_length,mean(gradient(1:my_length,1:size(A_Reduced,2))'),'g-.');
set(gca,'FontSize',12); 
legend('�','gradient','Location','northeast');
ylabel('�, gradient');
xlabel('iteration')



figure(8)
plot(1:size(V,2),V,'r-',1:size(v_n,2),v_n,'g-.',1:size(v_c,2),v_c*100,'b-');
set(gca,'FontSize',12); 
legend('f(x,s,r,t)','routing problem','communication problem','Location','northeast');
xlabel('iteration');
ylabel('problems');
disp(' Figure 8: Simulation result under both log-normal and gamma-gamma after optimization')
print_results( links,W_L,P_L,T_OPT ); 
 