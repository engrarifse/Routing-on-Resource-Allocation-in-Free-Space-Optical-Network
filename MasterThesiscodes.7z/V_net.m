function [X,s,t,fval]=V_net(A,p,Number_Nodes,Number_Links,Destination_Nodes)
% Solving problem 15 

%constraint 1
%  A*x(d)=s(d);
for j=1:length(Destination_Nodes)
    for i=1:Number_Nodes
        Constraint(((j-1)*Number_Nodes)+i,((j-1)*Number_Links)+1:((j-1)*Number_Links)+Number_Links)=A(i,:);
        Constraint(((j-1)*Number_Nodes)+i,(length(Destination_Nodes)*Number_Links)+((j-1)*Number_Nodes)+i)=-1;
    end;
end
[N_Row,N_col]=size(Constraint);
%constraint 2
%sum(x_d)=t
for i=1:Number_Links
    for j=1:length(Destination_Nodes)
        Constraint(N_Row+i,i+(j-1)*Number_Links)=1;
        Constraint(N_Row+i,N_col+i)=-1;
    end;
end;
%right hand side of optimisation problem

RHS=zeros(1,size(Constraint,1));

%lower and upeer of variables
lb=zeros(size(Constraint,2),1);
ub=ones(size(Constraint,2),1)*10^4;

for i=1:length(Destination_Nodes)
    lb(Number_Links*length(Destination_Nodes)+(i-1)*Number_Nodes+Destination_Nodes(i),1)=-10^4;
    ub(Number_Links*length(Destination_Nodes)+(i-1)*Number_Nodes+Destination_Nodes(i),1)=0;
end;

%finding a initial feasible point
f=zeros(size(Constraint,2),1);
grad=zeros(size(Constraint,2),1);
f(1:(length(Destination_Nodes)*Number_Links))=-1*ones((length(Destination_Nodes)*Number_Links),1);
f(size(Constraint,2)-Number_Links+1:size(Constraint,2))=1*ones(Number_Links,1);
options = optimset('Display','none');

[x0] = linprog(f,[],[],Constraint,RHS,lb,ub,[],options); %x0 is a feasible point


%Optimising 
    options =  optimset('Algorithm','interior-point',...
        'Display','off','MaxFunEvals',1000,'Maxiter',1000,'GradObj','on','TolX',1.e-015);
[out,fval,exitflag]=fmincon(@(x)Objective_V_net(x,Number_Nodes,Destination_Nodes,Number_Links,p,grad),x0,[],[], Constraint,RHS,lb,ub,[],options);
%Computing output variables
count=1;
for i=1:length(Destination_Nodes)
    for j=1:Number_Links
        X(i,j)=fix(out(count)*100)/100;
        count=count+1;
    end;
end;
for i=1:length(Destination_Nodes)
    for j=1:Number_Nodes
        s(i,j)=fix(out(count)*100)/100;
        count=count+1;
    end;
end;
for i=1:Number_Links
    t(i)=fix(out(count)*100)/100;
    count=count+1;
end;
fval=-fval;      %consider negative of the output from optimisation
end
