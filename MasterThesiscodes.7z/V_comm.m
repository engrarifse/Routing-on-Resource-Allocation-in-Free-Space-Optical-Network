function [P_L,W_L,fval]=V_comm(A,g,delta,p,Number_Nodes,Number_Links)
%%

Constraint=zeros(2*Number_Nodes,2*Number_Links);
%constraints 
%  Fr<=g;
%%r(i)=(P(i),W(i))
    for i=1:Number_Nodes
        Constraint(i,1:Number_Links)=max(0,A(i,:));
        Constraint(Number_Nodes+i,Number_Links+1:2*Number_Links)=max(0,A(i,:));
    end;

%right hand side of optimisation problem
for i=1:2*Number_Nodes
    RHS(i)=g(i);
end;

%lower value of variables
lb=zeros(size(Constraint,2),1);


%finding a initial feasible point
f=-1*ones(size(Constraint,2),1);
grad=zeros(size(Constraint,2),1);
options = optimset('Display','none');
x0 = linprog(f,Constraint,RHS,[],[],lb,[],[],options); %x0 is a feasible point

%Optimising the problem
options =  optimset('Display','off','Algorithm','interior-point',...
        'GradObj','on','MaxFunEvals',2000,'Maxiter',2000);
[out,fval,exitflag]=fmincon(@(x)Objective_V_comm(x,Number_Links,delta,p,grad),x0,Constraint,RHS,[],[],lb,[],[],options);

%Computing output variables
r=fix(out*10000)/10000;
for i=1:Number_Links
    P_L(i)=r(i);
    W_L(i)=r(Number_Links+i);
end;
fval=-fval;     %� consider negative of the output from optimisation
end