function  color_edges_sp(h,path,S ,color)
%color the edges in h that are in path 
%   Detailed explanation goes here
for i=1:numel(path),
    

    if (i ~= S &&  numel(cell2mat(path(i))) > 1 ) 
        temp_path=cell2mat(path(i));%every member of path is cell based array convert them to index based array to use in following 4 line
        set(h.Nodes(temp_path),'Color',[1 0.4 0.4])
        edges = getedgesbynodeid(h,get(h.Nodes(temp_path),'ID'));
        set(edges,'LineColor',color)
        set(edges,'LineWidth',1.5)
    end
    
 end


end

