function [flag,Destination_Nodes ] = CheckMatrix( A )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
flag=0;
    counter=1;
    n=size(A,1);
    Destination_Nodes=[];
    for i=1:n
        if mean(A(i,find(A(i,:))))==-1
            Destination_Nodes(counter)=i;
            counter=counter+1;
        end;
    end;
    if length(Destination_Nodes) && (length(Destination_Nodes)*size(A,2))
        flag=1;
    end;
    

end

