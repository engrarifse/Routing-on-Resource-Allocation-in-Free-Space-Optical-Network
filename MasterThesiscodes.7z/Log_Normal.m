function [ A_Reduced,Num_Link_new ] = Log_Normal(A,lambd,Ith,Io,dist,g_th )
%Input: A = node-link incidence matrox (N by L)
%           lambda = wave length (in meter)
%           dist = distance (in meter)
%           refr = refractive coefficient (in meter m^(-2/3))
%Output: variance between the nodes

transmittance = Ith/Io;
count=1;
for link=1:size(A,2)
    i=find(A(:,link)==1);
    j=find(A(:,link)==-1);
    var = (0.30545)*power((2*3.14/lambd),7/6)*(((1e-17)+((2.5e-15)-(1e-17))).*rand(1))* power(dist(i,j),11/6);
    std = sqrt(var); % standard deviation
    denumerator = 2*std*sqrt(2);
    g = 0.5 - 0.5 * erf(log(transmittance)/denumerator);
    if g>=g_th
       A_Reduced(:,count)=A(:,link);
       count=count+1;
    end
    
end;
Num_Link_new=count-1;
end