function [f,g]=Objective_V_comm(r,Number_Links,delta,p,g)
%f(i)=p(i)*phi(r(i))
%r(i)=(P(i),W(i))
%phi(r(i))=W(i)*(1+P(i)/(delta(i)*W(i)))
for i=1:Number_Links
    P_L(i)=r(i);
    W_L(i)=r(Number_Links+i);
end;

f=0;

for i=1: Number_Links
    if (delta(i)* W_L(i))>eps
        f=f+(p(i)*(W_L(i)*(log2(1+( P_L(i)/(delta(i)* W_L(i)))))));
    else
        f=f+(p(i)*(W_L(i)*(log2(1+( P_L(i)/(delta(i)* W_L(i)+eps))))));
    end;
end;
f=-f;
count=1;
for i=1:Number_Links
    g(count)=-1/(delta(i)*log(2)*(P_L(i)/(W_L(i)*delta(i)) + 1));
    g(Number_Links+count)= -1*(log(P_L(i)/(W_L(i)*delta(i)) + 1)/log(2) - P_L(i)/(W_L(i)*delta(i)*log(2)*(P_L(i)/(W_L(i)*delta(i)) + 1)));
    count=count+1;
end;



end



