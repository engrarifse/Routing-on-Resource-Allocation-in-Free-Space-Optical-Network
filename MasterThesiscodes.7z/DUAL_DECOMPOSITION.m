function [V,x,s,t,P_L,W_L,P_value, v_n,v_c,gradient,m_p]=DUAL_DECOMPOSITION (A,g,delta,Destination_Nodes,Num_iteration,Beta,p )
%This function solve problem 10 by DUAL DECOMPOSITION algorithm
%Outputs
%V: optimum function value 
%x: optimum amount of flow destined for nodes from each nodes
%s:  optimum value of source-sink vector
%t: optimum total amount of traffic on each link 
%W_L: Optimum bandwidths of each link
%P_L: Optimum power of each link
%P_value P computed in DUAL_DECOMPOSITION 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Number_Nodes=size(A,1);
Number_Links=size(A,2);

P_value=zeros(Num_iteration,Number_Links);
P_value(1,:)=p; %using the initial point

potential = [];
gradient = [];
current=realmax;
num_rows=0;
for i=1:Num_iteration % Subgradient Method start
    potential = [potential P_value];
    alfa=Beta/i;     % positive scalar stepsize
    
    % V = V_net+ V_comm
	% V_net:Function to Optimize Routing Problem 
	% V_comm:Function to Optimize communication  Problem
    [x,s,t,net(i)]=V_net(A,P_value(i,:),Number_Nodes,Number_Links,Destination_Nodes); % use linear programming to caluate V_net
                                                                                                                                                                                
                                                                                                
                                                                                        
    [P_L,W_L,comm(i)]=V_comm(A,g,delta,P_value(i,:),Number_Nodes,Number_Links);       % use linear programming to caluate V_comm
    

    for j=1:Number_Links % for each link claculate band width using hannon capacity formula 
        if (delta(j)* W_L(j))>eps %if newly calculated badwidth is less Floating-point difference
            h_l(j)=max((W_L(j)*(log2(1+( P_L(j)/(delta(j)* W_L(j))))))-t(j),0);           %Shannon capacity formula B*Log2(1+S/N)
                                                                                          %B=W_L=Bndwidth
                                                                                          %S/N=P_L(J)/delta(j)*W_L(j)
                                                                                          %B=W_L=Bndwidth
                                                                                          %B=W_L=Bndwidth
        else
            h_l(j)=max((W_L(j)*(log2(1+( P_L(j)/(eps+delta(j)* W_L(j))))))-t(j),0);        %Shannon capacity formula with the difference eps added to denom
        end;
    end;
    
    gradient(i,:) =  h_l;
    
    
    prev(i)=mean(gradient(i,:));
    
    stop=false;
    first_index=0;
    
    if(i>150)
        gradt=gradient(1:i,:)';
        mgradt=mean(gradt) ;
        mgradt = round(mgradt .* 10 ) / 10;
        last_five = mgradt(1:1,i-4:i) ;
         last_five = (last_five .* 1000 ) / 1000;
  
            
  
        result = findpattern( mgradt(1:1,1:i-4) ,last_five);
        if(numel(result)>10)
%            disp('**********************found the pattern done***********************')
           finished_index= result(numel(result));
           stop=true;
        end
    end
    if(stop   )
        num_rows=finished_index;
       break;
    else
        num_rows=i-1;
    end
    
    
    
    
    P_value(i+1,:)=P_value(i,:)-alfa*(h_l)      ;                           %Update Initial estimate
    
    v_n(i)=(net(i)); 
    v_c(i)=(comm(i));
 %   gradient(i)= h_l(1);
    V(i)=(net(i)+comm(i));                                                  %Update Optimum Function values
    
end; % Subgradient Method end
if(stop  ==false  )
        num_rows=Num_iteration;
       
        
    
    end

    m_p=P_value(1:num_rows,:);
end

