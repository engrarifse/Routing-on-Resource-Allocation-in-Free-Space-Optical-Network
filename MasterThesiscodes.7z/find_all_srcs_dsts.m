function [ all_srcs,all_dsts ] = find_all_srcs_dsts( A )
%UNTITLED6 Summary of this function goes here
%   Detailed explanation goes here

[ n,l ] =size(A);
mark_destination_nodes=zeros(1,n);

mark_soruce_node=zeros(1,n);

src_idx = 1;
dst_idx = 1;

for row_idx = 1 :n 
%     for end_idx = 1 :n 
%     end
     if ~isempty(find(A(row_idx,:)>0)) && isempty(find(A(row_idx,:)<0)) 
         all_srcs(src_idx)=row_idx;
         src_idx = src_idx +1;
     end
     if ~isempty(find(A(row_idx,:)<0)) && isempty(find(A(row_idx,:)>0)) 
          all_dsts(dst_idx)=row_idx;
          dst_idx = dst_idx+1;
     end
%       if find(A(row_idx,:)<0) && ~find(A(row_idx,:)>0) 
%          all_dsts(dst_idx)=row_idx;
%          dst_idx = dst_idx+1;
%      end
    
end


end

