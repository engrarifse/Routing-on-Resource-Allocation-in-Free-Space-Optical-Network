function [A,dist,x,y,adj_matrix]=make_data(n,l,mark_destination_nodes,mark_soruce_node)
%
%Inputs:
%n is number of nodes
%L is number of links

%Outputs:
%A: node-link incidence matrox (N by L)
%Destination_Nodes: Nodes that are just ended nodes not start nodes
%dist: Euclid distance between nodes

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
flag=0;

while ~flag
    dist=zeros(n,n);
    A=zeros(n,l);
    x=zeros(n,1);
    y=zeros(n,1);
    for i=1:n
        x(i)=randi(2600,1,1);
        y(i)=randi(2600,1,1);
    end;
    
    for i=1:n
        for j=1:n
            if i~=j
                dist(i,j)=sqrt((x(i)-x(j))^2+(y(i)-y(j))^2);
            end;
        end;
    end;
    
    
    %%%%%%%%%
    num_link=1;
    adj_matrix = zeros (n);
    max_attempt = l*1000;
    attemp_count =0 ; 
    while num_link<=l
        if(attemp_count == max_attempt)  
            disp('etror creating matrix try again');
            break;
        end
        start=randi(n,1,1);
        finish=randi(n,1,1);
      
        if(mark_destination_nodes(start) || mark_soruce_node( finish))
            donothing=1;
        elseif start~=finish &&  adj_matrix(start,finish)~=1
            adj_matrix(start,finish)=1;
            graph_is_dag = graphisdag(sparse(adj_matrix));
            if(graph_is_dag==0)
                adj_matrix(start,finish)= 0;
            else
                A(start,num_link)=1;
                A(finish,num_link)=-1;
                num_link=num_link+1;
                adj_matrix(start,finish)=1;
            end
        end;
        attemp_count = attemp_count +1;
    end;
    
    [flag] = CheckMatrix( A );

    
end;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%


end