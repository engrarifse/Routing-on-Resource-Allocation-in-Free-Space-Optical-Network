function [Smatrix,bi] = Make_BioGraphMatrix( A ,x,y,Destination_Nodes,X_OPT,S_OPT)
%this function make a square matrix related to bio graph object
Smatrix=zeros(size(A,1),size(A,1));
for link=1:size(A,2)
    i=find(A(:,link)==1);
    j=find(A(:,link)==-1);
    if i==4 || i==9 || i==18
        u=0;
    end;
    Smatrix(i,j)=1;
    
end;
bi= biograph(Smatrix);

for i=1:size(A,1)
    bi.nodes(i).position=[x(i) y(i)];
end;

BiTotal=bi;
[~,link_Number]=find(X_OPT);
for i=1:length(Destination_Nodes)
for k=1:size(A,1)
    BiTotal.nodes(k).position=[x(k) y(k)];
end;
[~,Nodes]=find(S_OPT(i,:)>0);
for j=1:length(Nodes)
    Links=find(A(Nodes(j),:)==1);
    for ll=1:length(Links)
        if X_OPT(i,Links(ll))
            Num_Link_Smatrix=sum(sum(Smatrix(1:Nodes(j)-1,:)))+ sum(sum(Smatrix(Nodes(j),1:Destination_Nodes(i)-1)))+1;
            BiTotal.Edges( Num_Link_Smatrix).LineWidth=3;
        end;
    end;
end;
 end;
 
for i=1:length(Destination_Nodes)
    BiTotal.nodes(Destination_Nodes(i)).Color=[1 0 0];
end;
view(BiTotal)





 for i=1:length(Destination_Nodes)
Bi=biograph(Smatrix);
for k=1:size(A,1)
    Bi.nodes(k).position=[x(k) y(k)];
end;
[~,Nodes]=find(S_OPT(i,:)>0);
for j=1:length(Nodes)
    Links=find(A(Nodes(j),:)==1);
    for ll=1:length(Links)
        if X_OPT(i,Links(ll))
            Num_Link_Smatrix=sum(sum(Smatrix(1:Nodes(j)-1,:)))+ sum(sum(Smatrix(Nodes(j),1:Destination_Nodes(i)-1)))+1;
            Bi.Edges( Num_Link_Smatrix).LineWidth=3;
        end;
    end;
end;
Bi.nodes(Destination_Nodes(i)).Color=[1 0 0];
view(Bi)
 end;


end

