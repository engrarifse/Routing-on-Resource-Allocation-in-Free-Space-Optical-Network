function [f,g]=Objective_V_net(x,Number_Nodes,Destination_Nodes,Number_Links,P,g)
f=0;
count=1;
for i=1:length(Destination_Nodes)
    for j=1:Number_Links
        X(i,j)=x(count);
        count=count+1;
    end;
end;
for i=1:length(Destination_Nodes)
    for j=1:Number_Nodes
        s(i,j)=x(count);
        count=count+1;
    end;
end;
for i=1:Number_Links
    t(i)=x(count);
    count=count+1;
end;


for i=1: length(Destination_Nodes)
    for j=1:Number_Nodes
        if j~=Destination_Nodes(i) 
             f=f+log(s(i,j));
        end;
    end;
end;

for i=1:Number_Links
    f=f-(P(i)*t(i));
end;
f=-f;

count=1;
for i=1:length(Destination_Nodes)
    for j=1:Number_Links
        count=count+1;
    end;
end;
for i=1:length(Destination_Nodes)
    for j=1:Number_Nodes
        if j~=Destination_Nodes(i)
        g(count)=1/log(s(i,j));
        end;
        count=count+1;
    end;
end;
for i=1:Number_Links
    g(count)=P(i);
    count=count+1;
end;


    

end

