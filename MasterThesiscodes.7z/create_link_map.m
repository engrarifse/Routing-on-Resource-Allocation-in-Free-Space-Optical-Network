function [ links ] = create_link_map( A )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes her
[ n,l ] = size(A);
ADJ_MAT = zeros(n);
count =1;
source_count = 1;
done = zeros(1,n);

node_link_map = zeros(n);

for colum = 1:size(A,2)
    for row = 1:size(A,1)
      flag = 0;
          if A(row,colum) == 1
              links(count,1) = row;  
            flag= 1;
          
          end
          if A(row,colum) == -1
             
              links(count,2) = row; % to create this array
                  flag= 1;
                  
            
          end         
    end
    if count <= size(links,1)
       ADJ_MAT(links(count,1),   links(count,2))=1; %p(count)
     node_link_map(links(count,1),   links(count,2))= count;
   
       if done(1,links(count,1)) == 0
           sources(source_count)=links(count,1);
           source_count = source_count+1;
           done(1,links(count,1))=1;
             %count =  count+1
       end
        count =  count+1;
     end 
     
end


end

