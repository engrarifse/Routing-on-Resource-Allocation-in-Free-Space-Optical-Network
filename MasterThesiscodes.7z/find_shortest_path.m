function  find_shortest_path(n,l,A,links,W_L,P_L, mark_soruce_node,mark_destination_nodes )
%function [ output_args ] = find_shortest_path(n,l,links,W_L,P_L  )
%   Detailed explanation goes here
BW_adj_map = zeros(n);
PW_adj_map = zeros(n);
for myidx = 1:numel(links)/2
   src =links(myidx,1);
   dst =links(myidx,2);
   BW_adj_map(src,dst)=W_L(myidx);
   PW_adj_map(src,dst)=P_L(myidx);
   
end
h2 = view(biograph(sparse(PW_adj_map),[],'ShowWeights','on'));
h = view(biograph(sparse(BW_adj_map),[],'ShowWeights','on'));

% all_srcs = find(mark_soruce_node);
% all_dsts = find(mark_destination_nodes);
[ all_srcs,all_dsts ] = find_all_srcs_dsts( A );
color = [
            1.0 0 0 ;
            0 1.0 0 ;
            0 0 1.0 ;
            1.0 1.0 0;
            0 1.0 1.0;
            1.0 0 1.0;
        ];
for src_idx = 1:numel(all_srcs );
    for dst_idx = 1:numel(all_dsts );
        src1 = all_srcs (src_idx);
        dst1 = all_dsts (dst_idx);

        [BW_dist,BW_path,BW_pred] = graphshortestpath(sparse(BW_adj_map), src1,dst1, 'Method','Dijkstra');
      
        [PW_dist,PW_path,PW_pred] = graphshortestpath(sparse(PW_adj_map),src1,dst1, 'Method','Dijkstra');

        color_edges_sp(h,({BW_path}),src1 , color(mod(src_idx,5)+1,:));
% 
% 
        color_edges_sp(h2,({PW_path}),src1 ,color(mod(src_idx,5)+1,:));
% 
    end
end
  set(h.Nodes((all_srcs) ),'Color',[0 1 0]);
  set(h2.Nodes((all_srcs) ),'Color',[0 1 0]);
  set(h.Nodes((all_dsts) ),'Color',[0 0 1]);
  set(h2.Nodes((all_dsts) ),'Color',[0 0 1]);

end

